"use client"

import dynamic from "next/dynamic"
import ChatInterface from "@/components/chat-interface"
import { Button } from "@/components/ui/button"
import { Home } from "lucide-react"
import Link from "next/link"

const PDFViewer = dynamic(() => import("@/components/pdf-viewer"), {
  ssr: false,
})

export default function PDFViewerPage() {
  const pdfUrl = "https://bitcoin.org/bitcoin.pdf"

  return (
    <div className="flex flex-col h-screen bg-gray-900">
      <header className="p-4 border-b border-gray-700">
        <Link href="/">
          <Button variant="outline" size="sm" className="text-gray-300 border-gray-700 hover:bg-gray-700">
            <Home className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </Link>
      </header>
      <div className="flex-grow flex">
        <div className="w-1/2 border-r border-gray-700">
          <PDFViewer url={pdfUrl} />
        </div>
        <div className="w-1/2">
          <ChatInterface />
        </div>
      </div>
    </div>
  )
}

