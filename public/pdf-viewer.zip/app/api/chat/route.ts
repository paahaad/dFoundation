import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import type { NextRequest } from "next/server"

export async function POST(req: NextRequest) {
  const { messages } = await req.json()

  const response = await generateText({
    model: openai("gpt-4o"),
    messages,
    system:
      "You are an AI assistant helping users understand the content of the Bitcoin whitepaper. Provide concise and accurate information based on the paper's content.",
  })

  return new Response(response.text)
}

