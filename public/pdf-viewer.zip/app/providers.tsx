"use client"

import type { ReactNode } from "react"
import { AI } from "ai"
import { openai } from "@ai-sdk/openai"

export function Providers({ children }: { children: ReactNode }) {
  return <AI model={openai("gpt-4o")}>{children}</AI>
}

