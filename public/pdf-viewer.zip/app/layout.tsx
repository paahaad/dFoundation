import type React from "react"
import "@/styles/globals.css"
import { Inter } from "next/font/google"
import { Providers } from "./providers"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "PDF Viewer with Chat",
  description: "A user-friendly PDF viewer with AI chat in dark mode",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} bg-gray-900 text-gray-100`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}



import './globals.css'