"use client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useChat } from "ai/react"

export default function ChatInterface() {
  const { messages, input, handleInputChange, handleSubmit } = useChat()

  return (
    <div className="flex flex-col h-full">
      <div className="flex-grow overflow-auto p-4 space-y-4">
        {messages.map((m) => (
          <div key={m.id} className={`${m.role === "user" ? "text-blue-400" : "text-green-400"}`}>
            <span className="font-bold">{m.role === "user" ? "You: " : "AI: "}</span>
            {m.content}
          </div>
        ))}
      </div>
      <form onSubmit={handleSubmit} className="p-4 border-t border-gray-700">
        <div className="flex space-x-2">
          <Input
            value={input}
            onChange={handleInputChange}
            placeholder="Ask about the PDF..."
            className="flex-grow text-white bg-gray-800 border-gray-700"
          />
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white">
            Send
          </Button>
        </div>
      </form>
    </div>
  )
}

